function [ind, badInd_ind] = segment_analysis1_v3(signal, t, L, type, DF, show)
%v3: has the option to choose ecg or ecgdiff for analysis (for some cases
%ecg is better that ecgdiff. should be used with segment_analysis2_v2

%v2: fixed problems for short duration signals where shifting them results
%in not detecting any peaks in the second round analysis

%Perform fiducial point detection on a biomedical signal by segmenting the
%signal into L parts. This helps to get rid of noise, variabilites, etc.
%Note: the minimum length of each segment data should be 5 sec. i.e.
%(length(signal)/fs)/L should be
%Note: signal length should be greater than L
%Note: currently works for ECG R-peak detection and PPG Trough
%detection.

% In
%           signal          input signal
%           t               signal time samples
%           L               segments' length
%           type            signal type: ECG, PPG
%
%
% Out
%           ind             heartbeat indices
%           badInd_ind      bad heartbeat indices in "ind". They are not
%           removed from ind as this may affect the further stage anayles.

% @M. Forouzanfar, 2/2018

%% Parameters
fs = round(1/mean(diff(t)));

%% 1st Detection
[ind] = segment_analysis2_v2(signal, t, L, type, DF, 0); %segment analysis works well when signal is not 0 for long time
% [ind] = find_trough(signal, t, show); %use this if not doing segment analysis
if show == 1
    figure, plot(t, signal, t(ind), signal(ind), '*')
    title('Initial Detection')
end

%% 2nd detection
t_shift = t(fs*L/2:end);% Delay is L/2 secs
signal_shift = signal(fs*L/2:end);% Delay is L/2 secs
L2 = min(length(signal_shift), L);
[inds] = segment_analysis2_v2(signal_shift, t_shift, L2, type, DF, 0); %segment analysis works well when signal is not 0 for long time
if show == 1
    %     figure, plot(t_shift, signal_shift, t_shift(inds), signal_shift(inds), '*')
    %     title('Initial Detection')
end
%% Merge the indices of the original and delayed versions to fix boundry issues
if ~isempty(inds) %ind2 could be empty if the signal is very short
    ind1 = [];%index on original
    ind2 = [];%index on shifted
    W = min(round(L/5), 20); %boundry width to be corrected (sec)
    for i = 1:1 + floor(length(signal)/(fs*L))-1
        [ind_temp] = find( t(ind)> i*L-W + t(1)  &  i*L+W + t(1) > t(ind) );
        ind_temp = ind(ind_temp);
        ind1 = [ind1; ind_temp];
        [ind_temp] = find(t_shift(inds)> i*L-W + t(1) & i*L+W + t(1) >t_shift(inds));
        ind_temp = inds(ind_temp);
        ind_temp = ind_temp + fs*L/2 -1;
        ind2 = [ind2; ind_temp];
    end
    ind = ind(~ismember(ind, ind1));%remove boundries from original
    ind = [ind; ind2];%add boundries from shifted
    ind = sort(ind); %sort indices
    %     ind(end) = []; %remove last to make sure there is ppg and icg data available for analysis
    %     ind(1) = []; %remove first to make sure other features happening prior to the Rpeak exist.
    
    if show == 1
        figure, plot(t, signal, t(ind), signal(ind), 'r*')
        title('Corrected Detection')
    end
end
%% Remove the last detected peak because it may add issues
if t(end)-t(ind(end)) < 0.4
    ind(end) = [];
end

%% Outlier detection (cause we detect very close peaks based on the set thresholds, here we remove very close detected peaks
badInd_ind = noisyPulse_detection(t, signal, ind, show);
