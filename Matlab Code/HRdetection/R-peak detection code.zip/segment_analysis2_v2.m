function [ind] = segment_analysis2_v2(signal, t, L, type, DF, show)
%v2: has the option to choose ecg or ecgdiff for analysis (for some cases
%ecg is better that ecgdiff
%perform fiducial point detection on a biomedical signal by segmenting the
%signal into L parts. This helps to get rid of noise, variabilites, etc.
%Note: the minimum length of each segment data should be 5 sec. i.e.
%(length(signal)/fs)/L should be

% @M. Forouzanfar, 10/2017

fs = round(1/mean(diff(t)));

%% Initial heart rate detection
window = min(length(signal), 120*fs); %number of samples (2 mins or if the signal is shorter the length of the signal)
%low pass filter (because signal was cut) and computer psd
[psd, psd_f] = pwelch(bandpass(signal, 0.5, 2, fs), window, [], [], fs);%50 percent overlap, nfft  is the greater of 256 or the next power of 2 greater than the length of the segments.
%If window is an integer, the signal is divided into segments of length window. The modified periodograms are computed using a Hamming window of length window.
%If window is not specified, By default, x is divided into the longest possible segments to obtain as close to but not exceed 8 segments with 50% overlap.
psd = 10*log10(psd);
if show == 1
    figure, plot(psd_f, psd, 'DisplayName','PSD')
end
[~, ind1] = min(abs(psd_f - 0.6));
[~, ind2] = min(abs(psd_f - 1.6));%changed from 1.5 to 1.6 for Thor 4/2/2018
[~, ind] = max(psd(ind1:ind2));
hr = 60*psd_f(ind+ind1-1); %beats per min
if show == 1
    hold on, plot(psd_f(ind1:ind2), psd(ind1:ind2), psd_f(ind+ind1-1), psd(ind+ind1-1), '*', 'DisplayName','Heart beat')
end


%% Find threshold for ignoring zero data
% Thr = var(signal)/4;
% [peaks, ~,~,~] = findpeaks(signal, t, 'MinPeakDistance', 0.5, 'MinPeakHeight', 0); % since time t is give as input, locs are in time. Parameters are also in time.
% Thr = 0.01 * (median(peaks))^2; %normalizing. 0.01 or higher maybe?
%first remove outliers to get a better estimate of signal variance
if  strcmp(type,'ecg')
    param1 = 3;
    param2 = 10;
    param3 = 0.01;
elseif strcmp(type,'ppg')
    param1 = 20;
    param2 = 5;
    param3 = 0.001;
end
signal_enhanced = signal;
for i = 1:param1 %while gets stock in the loop even with high outlier_thr
%     outlier_ind = [];
    %Hampel identifier
    %     outlier_ind = abs( segmenti-median(segmenti) ) > outlier_thr*1.48*median( abs( segmenti-median(segmenti) ) );%detects both positive and negative outliers %logical indices% if use "find" then will give real indices
    outlier_ind = abs( signal_enhanced-nanmean(signal_enhanced)) > param2* nanstd(signal_enhanced); %using the std instead of mad works better for signals like ECG that have high intrinsic variability
    signal_enhanced(outlier_ind) = NaN; %NaNs at outliers
end
nanInd = isnan(signal_enhanced);
signal_enhanced(nanInd) = interp1(t(~nanInd), signal(~nanInd), t(nanInd),'linear','extrap'); %fix outliers
% figure, plot(signal)
% hold on, plot(signal_enhanced)

if  strcmp(type,'ecg')
    Thr = param3*var(signal_enhanced); %0.01 works for most cases except 1 so far (857_SL_MNP_N2_HotF)
elseif strcmp(type,'ppg')
    Thr = param3*var(signal_enhanced);
end
%% Cut and find fiducial point indices
ind = [];
for i = 1:floor(length(signal)/(fs*L)) %1+floor(length(signal)/(fs*L))
    segment_done = i;
    if i == floor(length(signal)/(fs*L))%last segment%1+floor(length(signal)/(fs*L))
        segmenti = signal( 1+(i-1)*L*fs : end);
        ti = t( 1+(i-1)*L*fs : end);
    else
        segmenti = signal( 1+(i-1)*L*fs : i*L*fs);% all segments except the last
        ti = t( 1+(i-1)*L*fs : i*L*fs);
        %         figure, plot(ti, segmenti)
    end
    %if length of segmenti is less that 5 secs, the analysis will not be
    %performed. This could happen for the last segment. It is probably
    %now fixed by extending the last two segments into one
    if length(segmenti)/fs < 5
        break
    end
    %% Note: any index found on segmenti should be added by (i-1)*L*fs
    %% find fiducial point indices
    if var(segmenti) > Thr %check if signal exists
        segment_done;
        if strcmp(type, 'ecg')
            if DF == 1 
                [indi] = find_rpeak_ecgDiff_v1(segmenti, ti, show, hr);
            elseif DF == 0
                [indi] = find_rpeak(segmenti, ti, show, hr);
            end
            %             hold on, plot(ti(indi), segmenti(indi), 'ks')
        end
        if strcmp(type, 'ppg')
            [indi] = find_trough_v2(segmenti, ti, show, hr);% under construction
        end
        %% correct indices
        indi = indi + (i-1)*L*fs;
        ind = [ind; indi];
    end
end
if show == 1
    figure, plot(t, signal, t(ind), signal(ind), 'v')
    title('original signal with detected fiducial points')
end

