function noisyPulse_ind = noisyPulse_detection(t, signal, ind, show)

%returns bad pulse indices with no need for a reference such as rpeak
%only detects too close pulses. Does not care about too far pulses, because
%the function is originally designed to detect too close R peaks as the
%R-peak detection algorithm has set to detect very close R peaks that may
%detect some extra points thar are corrected here.

%@M. Forouzanfar, 5-2018

find_good_indices_in_bad_indices = 0;%beacuse of the high threshold value set in detection of bandInd_ind on line 14, this step does not work well.

%% Outlier detection (cause we detect very close peaks based on the set thresholds in segment_analysis, here we remove very close detected peaks
diff_ind = [diff(ind(1:2)); diff(ind)];
%bad indices in "ind" (these are not going to be removed, but rather send
%as extra output so that we know which indices not to use for further
%analysis:
badInd_ind =  ( median(diff_ind) - diff_ind ) > 8*1.48*median( abs( diff_ind-median(diff_ind) ) ) ;%detects only close peaks not too far ones %logical indices% if use "find" then will give real indices
%Note: Don't go bellow 8. E.g. last subject os smart4health at 2.4e4 has
%very high heartbeat that needs min of 6. Or Sbj 23 in the same dataset
%('865_SG_MNP_N2_HotF.mat').
%Note: the above line of code is almost equal to:badInd_ind =
%isoutlier(diff_ind,'ThresholdFactor', 8);  The difference is that we are
%only detection outliers as too close peaks not too far peaks. For
%detecting too far outliers use abs( median(diff_ind) - diff_ind ) which is
%not the case here.


%local outlier removal: (did not look to work better than the overal analysis above)
% window = 200; %local window length in samples
% badInd_ind = isoutlier(diff_ind, 'movmedian', window, 'ThresholdFactor', 8);
%Other outlier detection methods in Matlab:
% badInd_ind = isoutlier(diff_ind, 'grubbs','ThresholdFactor', 0.5);

% figure, plot(t, signal, t(ind), signal(ind), 'r*')
% hold on, plot(t(ind(badInd_ind)), signal(ind(badInd_ind)), 'y^', 'DisplayName','outlier peaks')
% legend('show')


%Correct some of those badInd_inds that are not really bad
if find_good_indices_in_bad_indices == 1
    i = 1;
    goodInd_ind = []; %good indices in "ind" (find good indices in "ind" and remove them from badInd_ind.
    while 1
        tmp1 = find (badInd_ind == true);%logic to real ind number
        tmp2 = double([0; diff(tmp1)] == 1);%those connected
        tmp3 = ([0; diff(tmp2)] == 1);%the first out of those connected
        goodInd_ind = [goodInd_ind; tmp1(tmp3)];
        badInd_ind(goodInd_ind) = false;%remove good indices
        if sum(tmp3) == 0
            break
        end
        i = i+1;
    end
    goodInd_ind = sort(goodInd_ind);
    badInd_ind(goodInd_ind) = false; %remove good indices from the list of outliers
end

if show == 1
    %     hold on, plot(t(ind(goodInd_ind)), signal(ind(goodInd_ind)), 'g^')
    %     hold on, plot(t(ind(badInd_ind)), signal(ind(badInd_ind)), 'yv')
    %     title('Last bad outliers')
    %     legend('show')
end

% ind(badInd_ind) = [];%remove real outliers
if show == 1
    hold on, plot(t(ind(badInd_ind)), signal(ind(badInd_ind)), 'y^', 'DisplayName','outlier peaks')
    legend('show')
end

noisyPulse_ind = badInd_ind;