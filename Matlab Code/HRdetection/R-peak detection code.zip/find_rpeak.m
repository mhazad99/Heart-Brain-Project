function [rpeak_ind] = find_rpeak(segmenti, ti, show, varargin)

%Finds the R-peaks of segmenti with time indices ti.
%The signal is better to be filtered before being cut and fed to this
%function.

% @M. Forouzanfar, 10-2017

%% parameters
%outlier detection params
outlier_thr = 10; %for ecg appears that it needs to be high!
%envelope detection params
distance_ratio = 1;%0.9 for segment analysis. 0.6 for whole night analysis%was 1 until bahrami
height_ratio = 5; %was 5 until bahrami
%R-peak detection params
MinPeakDistance_ratio = 0.45;%0.6 for segment analysis. lower for whole night analysis.%was 0.4 until hrv with Ms Bahrami that changed to 0.5
MinPeakHeight = 0.5;
MinPeakProminence = 0.6;%0.6 for both ecg and ecgdiff
%filter params for psd
ecg_lf = 0.6;%very strong filtering to get rid of respiration
ecg_hf = 1.8;%very strong filtering to get rid of harmonics that are sometime higher than fundamental
%psd parameters
if length(varargin) == 1
    hr_min = 0.7*varargin{:}/60;%varargmin is initial hr estimate in bpm
    hr_max = 1.6*varargin{:}/60;%1.6 for ecg, and 2.1 for ecg_diff
else
    hr_min = 0.6;
    hr_max = 1.7;%1.7 for ecg, and 2 for ecg_diff
end

%sampling rate
fs = round(1/mean(diff(ti)));

if show == 1
    figure, plot(ti, segmenti, 'DisplayName','Segmenti');
end
%% outlier removal and correction
% outlier_ind = 1;
% while sum(outlier_ind) > 0
for i = 1:1 %while gets stock in the loop even with high outlier_thr
    outlier_ind = [];
    %Hampel identifier
%     outlier_ind = abs( segmenti-median(segmenti) ) > outlier_thr*1.48*median( abs( segmenti-median(segmenti) ) );%detects both positive and negative outliers %logical indices% if use "find" then will give real indices
    outlier_ind = abs( segmenti-mean(segmenti)) > outlier_thr* std(segmenti); %using the std instead of mad works better for signals like ECG that have high intrinsic variability
    segmenti(outlier_ind) = interp1(ti(~outlier_ind), segmenti(~outlier_ind), ti(outlier_ind),'linear','extrap'); %fix outliers
end
if show == 1
    hold on, plot(ti, segmenti, 'DisplayName','Outliers removed');
end
%% find heart rate
window = min(length(segmenti), 120*fs); %number of samples (2 mins or if the signal is shorter the length of the signal)
%low pass filter (because signal was cut) and computer psd
%high pass filter as well: very important: we want to get rid of the peaks
%caused by respiration and also harmonics of HR
[psd, psd_f] = pwelch(bandpass(segmenti, ecg_lf, ecg_hf, fs), window, [], [], fs);%50 percent overlap, nfft  is the greater of 256 or the next power of 2 greater than the length of the segments.
%If window is an integer, the signal is divided into segments of length window. The modified periodograms are computed using a Hamming window of length window.
%If window is not specified, By default, x is divided into the longest possible segments to obtain as close to but not exceed 8 segments with 50% overlap.
psd = 10*log10(psd);
if show == 1
    figure, plot(psd_f, psd, 'DisplayName','PSD')
end
[~, ind1] = min(abs(psd_f - hr_min));
[~, ind2] = min(abs(psd_f - hr_max));
[~, ind] = max(psd(ind1:ind2));
hr = 60*psd_f(ind+ind1-1); %beats per min
if show == 1
    hold on, plot(psd_f(ind1:ind2), psd(ind1:ind2), psd_f(ind+ind1-1), psd(ind+ind1-1), '*', 'DisplayName','Heart beat')
end
%% envelope detection
rr = 60 / hr;
np = round(distance_ratio * rr * fs); %number of samples for peak detection. Should be 2 or 3 times of the rr interval to avoide unwanted peaks
% method 1: matlab envelope function (does not work well!)
%     [yupper,ylower] = envelope(segmenti,np,'peak');
% method 2: peak detection
[peak_amp, peak_t,~,~] = findpeaks(segmenti, ti, 'MinPeakDistance', np/fs); % since time t is give as input, locs are in time. Parameters are also in time.
MinPeakHeight1 = (1/height_ratio)*median(peak_amp);
[peak_amp, peak_t,~,~] = findpeaks(segmenti, ti, 'MinPeakDistance', np/fs, 'MinPeakHeight', MinPeakHeight1); % since time t is give as input, locs are in time. Parameters are also in time.
[trough_amp, trough_t,~,~] = findpeaks(-segmenti, ti, 'MinPeakDistance', np/fs); % since time t is give as input, locs are in time. Parameters are also in time.
MinPeakHeight2 = (1/height_ratio)*median(trough_amp);
[trough_amp, trough_t,~,~] = findpeaks(-segmenti, ti, 'MinPeakDistance', np/fs, 'MinPeakHeight', MinPeakHeight2); % since time t is give as input, locs are in time. Parameters are also in time.
%interpolate
upper_env = interp1(peak_t, peak_amp, ti, 'linear','extrap');%'pchip' extrapolates by default, but 'linear' does not.
lower_env = interp1(trough_t, -trough_amp, ti, 'linear','extrap');%'pchip' extrapolates by default, but 'linear' does not.
if show == 1
    figure, plot(ti, segmenti, peak_t, peak_amp, trough_t, -trough_amp)
    hold on, plot(ti, upper_env, 'DisplayName','Upper Envelope')
    hold on, plot(ti, lower_env, 'DisplayName','Lower Envelope')
end
%% normalization
segmenti = segmenti./(upper_env-lower_env);
if show == 1
    figure, plot(ti, segmenti, 'DisplayName','Normalized segmenti')
end
%% Filter: make sure the mean is gone
segmenti = segmenti-mean(segmenti);
if show == 1
    hold on, plot(ti, segmenti, 'DisplayName','Normalized segmenti - mean')
end
%% Rpeak detection
% segmenti_reverse = - segmenti; %PPG troughs are less affected by wave reflections
% MinPeakHeight = MinPeakHeight./median(upper_env-lower_env);
[~, rpeak_t,~,~] = findpeaks(segmenti, ti, 'MinPeakProminence', MinPeakProminence, 'MinPeakDistance', MinPeakDistance_ratio * rr); % since time t is give as input, locs are in time. Parameters are also in time.
% find indices
rpeak_ind = find_index(ti, rpeak_t);
if show == 1
    hold on, plot(ti(rpeak_ind), segmenti(rpeak_ind), '*','DisplayName','Rpeaks')
end
